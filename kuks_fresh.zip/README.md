# Vue 3 + Vite
# instalar node
# clonar repositorio git
# ejecutar npm install
# ejecutar npm run dev
# listo!!!!